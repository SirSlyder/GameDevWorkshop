﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PaddleScript : MonoBehaviour {

	public bool isAI;
	Vector3 oldPos;
	public float vel = 0;
	public float AISpeed = 5;
	private float AISpeedNew;
	public float AISpeedMultiplier = 1;
	public float AISpeedModifier = 1.0f; //what is set in the menu
	public Text AISpeedModText;

    public bool moveUsingMouse = true;
    private Vector3 previousMousePosition; //where the mouse has been previously
    public float playerPaddleSpeed = 5; //how much the paddle should move using keyboard

	public float yOffset = 0;

	public float yBoundMax = 3.88f;
	public float yBoundMin = -3.88f;
	private bool isPlaying = false;

	public int paddleSize = 15;
	public Text paddleText;

	public void SizeUp(){
		if (paddleSize < 25) {
			paddleSize += 1;
			transform.localScale = new Vector3 (paddleSize, 3, 0);
			paddleText.text = paddleSize.ToString ();
			yBoundMax -= 0.05f;
			yBoundMin += 0.05f;
		}
	}

	public void SizeDown(){
		if (paddleSize > 5) {
			paddleSize -= 1;
			transform.localScale = new Vector3 (paddleSize, 3, 0);
			paddleText.text = paddleSize.ToString ();
			yBoundMax += 0.05f;
			yBoundMin -= 0.05f;
		}
	}

	public void SpeedUp(){
		if (AISpeedModifier < 2.5f) {
			AISpeedModifier += 0.1f;
			AISpeedModifier = Mathf.Round (AISpeedModifier * 10) / 10;
			AISpeedModText.text = AISpeedModifier.ToString ();
		}
	}

	public void SpeedDown(){
		if (AISpeedModifier > 0.5f) {
			AISpeedModifier -= 0.1f;
			AISpeedModifier = Mathf.Round (AISpeedModifier * 10) / 10;
			AISpeedModText.text = AISpeedModifier.ToString ();
		}
	}

	void Start(){
		StartCoroutine("CalculateVelocity");
	}
	
	// Update is called once per frame
	void Update () {
		if (isPlaying) {
            if (!isAI) {
                #if UNITY_STANDALONE || UNITY_WEBPLAYER || UNITY_EDITOR || UNITY_WEBGL

                Vector3 vec = new Vector3(transform.position.x, transform.position.y, transform.position.z);

                Vector3 mousePos = Input.mousePosition;

                transform.position = new Vector2(transform.position.x, transform.position.y + (Input.GetAxisRaw("Vertical") * playerPaddleSpeed * Time.deltaTime));

                if(previousMousePosition != mousePos) //mouse has moved, control using mouse
                {
                    moveUsingMouse = true;
                    previousMousePosition = mousePos;
                } else if(mousePos == previousMousePosition && Input.GetButton("Vertical")) //mouse hasn't moved, control with W/S or Up Arrow/Down Arrow
                {
                    moveUsingMouse = false;
                }
                if (moveUsingMouse == true)
                {
                    vec = Input.mousePosition;
                    vec = Camera.main.ScreenToWorldPoint(vec);
                } else
                {
                    vec = new Vector3(vec.x, vec.y + (Input.GetAxisRaw("Vertical") * playerPaddleSpeed * Time.deltaTime), vec.z);
                }
				if (vec.y > yBoundMax) {
					vec = new Vector2 (vec.x, yBoundMax);
				} else if (vec.y < yBoundMin) {
					vec = new Vector2 (vec.x, yBoundMin);
				}
				transform.position = new Vector3 (-5.25f, vec.y, 0);

				#endif
			} else {
				if (GameObject.Find ("ball").GetComponent<Rigidbody2D> ().velocity.magnitude > 5 && GameObject.Find ("ball").GetComponent<ballScript> ().phys != ballScript.PhysicsType.Relative) {
					AISpeedNew = AISpeed + (GameObject.Find ("ball").GetComponent<Rigidbody2D> ().velocity.magnitude / 7.5f);
				} else {
					AISpeedNew = AISpeed;
					if (GameObject.Find ("ball").GetComponent<ballScript> ().phys == ballScript.PhysicsType.Relative) {
						if (GameObject.Find ("playerPaddle").transform.position.y > transform.position.y) {
							yOffset = 0.5f;
						} else {
							yOffset = -0.5f;
						}
					}
				}
				if (GameObject.Find ("ball").GetComponent<Rigidbody2D> ().velocity.x > 0) {
					AISpeedMultiplier = 1;
				} else {
					AISpeedMultiplier = 0.5f;
				}
				if (transform.position.y > GameObject.Find ("ball").transform.position.y) {
					transform.position = Vector3.MoveTowards (transform.position, new Vector3 (5.25f, GameObject.Find ("ball").transform.position.y + yOffset, 0), (AISpeedNew * AISpeedModifier * AISpeedMultiplier) * Time.deltaTime);
					if (transform.position.y > yBoundMax) {
						transform.position = new Vector3 (5.25f, yBoundMax, 0);
					} else if (transform.position.y < yBoundMin) {
						transform.position = new Vector3 (5.25f, yBoundMin, 0);
					}
				} else {
					transform.position = Vector3.MoveTowards (transform.position, new Vector3 (5.25f, GameObject.Find ("ball").transform.position.y + yOffset, 0), (AISpeedNew * AISpeedModifier * AISpeedMultiplier) * Time.deltaTime);
					if (transform.position.y > yBoundMax) {
						transform.position = new Vector3 (5.25f, yBoundMax, 0);
					} else if (transform.position.y < yBoundMin) {
						transform.position = new Vector3 (5.25f, yBoundMin, 0);
					}
				}
			}
		} else {
			transform.position = new Vector3 (transform.position.x, 0, 0);
		}
	}

	IEnumerator CalculateVelocity(){
		while (true){
			oldPos = transform.position;
			yield return new WaitForEndOfFrame ();
			if (oldPos.y > transform.position.y) {
				vel = -((oldPos - transform.position) / Time.deltaTime).magnitude;
			} else {
				vel = ((oldPos - transform.position) / Time.deltaTime).magnitude;
			}
		}
	}

	public void Play(){
		isPlaying = true;
	}

	void StopPlaying(){
		isPlaying = false;
	}
}
