﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class soundScript : MonoBehaviour {

	public bool soundEnabled = true;

	public void ToggleSound () {
		soundEnabled = !soundEnabled;
		if (soundEnabled) {
			AudioListener.volume = 1;
		} else {
			AudioListener.volume = 0;
		}
	}
}
