﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class timerScript : MonoBehaviour {

	public GameObject ball;

	public GameObject menu;
	public GameObject[] componentsToDeactivate;

	public AudioClip countdownClip;
	public AudioClip beginClip;

	public void Play(){
		StartCoroutine ("CountDown");
	}

    IEnumerator CountDown(){
		GetComponent<Text> ().fontStyle = FontStyle.Bold;
		GetComponent<Text> ().fontSize = 100;
		ball.transform.position = new Vector3(20, 0, 0);
		GetComponent<AudioSource> ().clip = countdownClip;
		GetComponent<AudioSource> ().Play ();
		GetComponent<Text> ().text = "3";
		yield return new WaitForSeconds (1);
		GetComponent<AudioSource> ().Play ();
		GetComponent<Text> ().text = "2";
		yield return new WaitForSeconds (1);
		GetComponent<AudioSource> ().Play ();
		GetComponent<Text> ().text = "1";
		yield return new WaitForSeconds (1);
		GetComponent<Text> ().text = "";
		GetComponent<AudioSource> ().clip = beginClip;
		GetComponent<AudioSource> ().Play ();
		yield return new WaitForSeconds (1);
		ball.SetActive (true);
		ball.SendMessage ("Play");
	}

	void Win(){
		GetComponent<Text> ().fontStyle = FontStyle.Normal;
		GetComponent<Text> ().text = "you win";
		StartCoroutine ("ReturnToMenu", 3);
	}

	void Lose(){
		GetComponent<Text> ().fontStyle = FontStyle.Normal;
		GetComponent<Text> ().text = "you lose";
		StartCoroutine ("ReturnToMenu", 3);
	}

	public void Quit(){
		StopCoroutine ("CountDown");
		GetComponent<AudioSource> ().clip = countdownClip;
		StartCoroutine ("ReturnToMenu", 0);
	}

	IEnumerator ReturnToMenu(int TimeToWait){
		yield return new WaitForSeconds (TimeToWait);
		GetComponent<Text> ().fontStyle = FontStyle.Normal;
		GetComponent<Text> ().fontSize = 50;
		GetComponent<AudioSource> ().clip = countdownClip;
		GetComponent<AudioSource> ().Play ();
		GetComponent<Text> ().text = "Returning to menu in 3";
		yield return new WaitForSeconds (1);
		GetComponent<AudioSource> ().Play ();
		GetComponent<Text> ().text = "Returning to menu in 2";
		yield return new WaitForSeconds (1);
		GetComponent<AudioSource> ().Play ();
		GetComponent<Text> ().text = "Returning to menu in 1";
		yield return new WaitForSeconds (1);
		GetComponent<Text> ().text = "";
		GetComponent<AudioSource> ().clip = beginClip;
		GetComponent<AudioSource> ().Play ();

		ball.GetComponent<ballScript> ().playerText.text = "0";
		ball.GetComponent<ballScript> ().aiText.text = "0";
		ball.SendMessage ("StopPlaying");

		menu.SetActive (true);
		foreach (GameObject i in componentsToDeactivate) {
			i.SetActive (false);
		}
		GameObject.Find ("playerPaddle").GetComponent<PaddleScript>().SendMessage("StopPlaying");
		GameObject.Find ("aiPaddle").GetComponent<PaddleScript>().SendMessage("StopPlaying");
	}
}
