﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class obstacleScript : MonoBehaviour {

	public GameObject[] obstacles;
	public int obstacle = 0;
	public Text obstacleText;

	void Awake(){
		foreach (GameObject i in obstacles) {
			i.SetActive (false);
		}
	}

	// Update is called once per frame
	public void ObstaclePlus () {
		obstacle += 1;
		if (obstacle > obstacles.Length) {
			obstacle = 0;
			obstacleText.text = obstacle.ToString ();
			foreach (GameObject i in obstacles) {
				i.SetActive (false);
			}
		} else {
			obstacleText.text = obstacle.ToString ();
			foreach (GameObject i in obstacles) {
				i.SetActive (false);
			}
			obstacles [obstacle - 1].SetActive (true);
		}
	}

	public void ObstacleMinus () {
		obstacle -= 1;
		if (obstacle < 0) {
			obstacle = obstacles.Length;
			obstacleText.text = obstacle.ToString ();
			foreach (GameObject i in obstacles) {
				i.SetActive (false);
			}
			obstacles [obstacle - 1].SetActive (true);
		} else {
			obstacleText.text = obstacle.ToString ();
			foreach (GameObject i in obstacles) {
				i.SetActive (false);
			}
			if (obstacle != 0) {
				obstacles [obstacle - 1].SetActive (true);
			}
		}
	}
}
