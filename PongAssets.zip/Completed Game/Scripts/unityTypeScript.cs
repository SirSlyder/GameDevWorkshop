﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class unityTypeScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		#if UNITY_STANDALONE || UNITY_EDITOR
		GetComponent<TextMesh>().text = "Currently playing on Standalone";
		#elif UNITY_WEBPLAYER || UNITY_WEBGL
		GetComponent<TextMesh>().text = "Currently playing on Webplayer/WebGL";
		#elif UNITY_IOS || UNITY_ANDROID || UNITY_WP8 || UNITY_IPHONE
		GetComponent<TextMesh>().text = "Currently playing on Mobile";
		#endif
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
