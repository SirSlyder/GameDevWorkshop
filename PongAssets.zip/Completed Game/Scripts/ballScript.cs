﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ballScript : MonoBehaviour {

	public float vel;
	public float speedModifier = 1;
	public Text speedModText;

	public bool hasTrail = true;

	public enum PhysicsType {Relative = 0, Velocity = 1, Gravity = 2};
	public PhysicsType phys;
	public int physicsInt = 0;
	public Text physText;

	public int scoreLimit = 5;
	public int playerScore = 0;
	public int aiScore = 0;

	public Text scoreLimitText;
	public TextMesh playerText;
	public TextMesh aiText;


    public void Play () {
		playerScore = 0;
		aiScore = 0;
		playerText.text = "0";
		aiText.text = "0";
		GetComponent<TrailRenderer> ().enabled = false;

		int sideToPick = Random.Range (0, 2) * 2 - 1;
		transform.position = new Vector3(0.4f * sideToPick, 0, 0);
		if (hasTrail) {
			GetComponent<TrailRenderer> ().enabled = true;
		}
		if (phys == PhysicsType.Gravity) {
			GetComponent<Rigidbody2D> ().gravityScale = 1 * speedModifier;
		} else {
			GetComponent<Rigidbody2D> ().gravityScale = 0;
		}
		//Debug.Log (sideToPick);

		GetComponent<Rigidbody2D> ().AddForce (transform.TransformDirection (Vector3.right * 250 * sideToPick * speedModifier));
		GetComponent<Rigidbody2D> ().AddForce (transform.TransformDirection (Vector3.up * speedModifier * Random.Range(-125, 125)));
	}

	public void ScoreUp(){
		if (scoreLimit < 10) {
			scoreLimit += 1;
			scoreLimitText.text = scoreLimit.ToString ();
		}
	}

	public void ScoreDown(){
		if (scoreLimit > 1) {
			scoreLimit -= 1;
			scoreLimitText.text = scoreLimit.ToString ();
		}
	}

	public void PhysModeUp(){
		physicsInt += 1;
		if (physicsInt > 2) {
			physicsInt = 0;
			phys = PhysicsType.Relative;
			physText.text = "position Based";
		}
		if (physicsInt == 1) {
			phys = PhysicsType.Velocity;
			physText.text = "Speed Based";
		} else if (physicsInt == 2) {
			phys = PhysicsType.Gravity;
			physText.text = "Gravity based";
		}
	}

	public void PhysModeDown(){
		physicsInt -= 1;
		if (physicsInt < 0) {
			physicsInt = 2;
			phys = PhysicsType.Gravity;
			physText.text = "Gravity Based";
		}
		if (physicsInt == 1) {
			phys = PhysicsType.Velocity;
			physText.text = "Speed Based";
		} else if (physicsInt == 0) {
			phys = PhysicsType.Relative;
			physText.text = "Position Based";
		}
	}

	public void ToggleTrail(){
		hasTrail = !hasTrail;
	}

	public void SpeedUp(){
		if (speedModifier < 2.5f) {
			speedModifier += 0.1f;
			speedModifier = Mathf.Round (speedModifier * 10) / 10;
			speedModText.text = speedModifier.ToString ();
		}
	}

	public void SpeedDown(){
		if (speedModifier > 0.5f) {
			speedModifier -= 0.1f;
			speedModifier = Mathf.Round (speedModifier * 10) / 10;
			speedModText.text = speedModifier.ToString ();
		}
	}

	// Update is called once per frame
	void Update () { 
        //playerText.text = playerScore.ToString();
        //aiText.text = aiScore.ToString();
	}

    //transform.Translate (Vector3.right * 0.05f);
    //vel = GetComponent<Rigidbody2D>().velocity.magnitude;

	void OnCollisionEnter2D (Collision2D other){

        if (other.transform.tag == "Player")
        {
            float forceAdded = 0;

            if (phys == PhysicsType.Velocity || phys == PhysicsType.Gravity)
            {
                forceAdded = other.gameObject.GetComponent<PaddleScript>().vel;
                if (phys == PhysicsType.Gravity)
                {
                    if (forceAdded < 0)
                    {
                        forceAdded = 0;
                    }
                    GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, 5);
                }
                if (forceAdded != float.NaN)
                {
                    if (forceAdded > 12)
                    {
                        forceAdded = 12;
                    }
                }
                else
                {
                    forceAdded = 0;
                }
            }
            else if (phys == PhysicsType.Relative)
            {
                Vector3 pos = transform.position;
                forceAdded = (pos.y -= other.transform.position.y) * 25 * (15 / other.transform.localScale.x);
                GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, 0);
            }
            GetComponent<Rigidbody2D>().AddForce(transform.TransformDirection(Vector3.up * speedModifier * (10 * forceAdded)));
        }
        else if (other.transform.tag == "Goal")
        {
            GetComponent<Rigidbody2D>().velocity = Vector3.zero;
            if (other.transform.name == "goalRight")
            {
                playerScore += 1;
                playerText.text = playerScore.ToString();
                StartCoroutine("Score", 0);
            }
            else
            {
                aiScore += 1;
                aiText.text = aiScore.ToString();
                StartCoroutine("Score", 1);
            }
        }
        transform.eulerAngles = Vector3.Reflect(transform.eulerAngles, other.transform.TransformDirection(Vector3.up));
    }


    IEnumerator Score(int side){
		GetComponent<Rigidbody2D> ().gravityScale = 0;
		GetComponent<Rigidbody2D> ().velocity = Vector2.zero;

		GetComponent<AudioSource> ().Play ();

		GetComponent<TrailRenderer> ().enabled = false;
		transform.position = new Vector3 (20, 0, 0);
		yield return new WaitForSeconds (GetComponent<AudioSource> ().clip.length);
		if (phys == PhysicsType.Gravity) {
			GetComponent<Rigidbody2D> ().gravityScale = 1 * speedModifier;
		}

		if (side == 0) {
			transform.position = new Vector3 (-0.4f, 0, 0);
			if (playerScore < scoreLimit) {
				GetComponent<Rigidbody2D> ().AddForce (transform.TransformDirection (Vector3.left * speedModifier * 250));
				GetComponent<Rigidbody2D> ().AddForce (transform.TransformDirection (Vector3.up * speedModifier * Random.Range (-175, 175)));
			} else {
				GetComponent<Rigidbody2D> ().gravityScale = 0;
				transform.position = new Vector3 (20, 0, 0);
				GameObject.Find ("Timer").SendMessage ("Win");
			}
		} else {
			transform.position = new Vector3(0.4f, 0 ,0);
			if (aiScore < scoreLimit) {
				GetComponent<Rigidbody2D> ().AddForce (transform.TransformDirection (Vector3.right * speedModifier * 250));
				GetComponent<Rigidbody2D> ().AddForce (transform.TransformDirection (Vector3.up * speedModifier * Random.Range (-175, 175)));
			} else {
				GetComponent<Rigidbody2D> ().gravityScale = 0;
				transform.position = new Vector3 (20, 0, 0);
				GameObject.Find ("Timer").SendMessage ("Lose");
			}
		}

		if (hasTrail) {
			GetComponent<TrailRenderer> ().enabled = true;
		}
	}

	public void StopPlaying(){
		StopCoroutine ("Score");
		transform.position = new Vector3 (20, 0, 0);
		GetComponent<Rigidbody2D> ().velocity = Vector2.zero;
		GetComponent<Rigidbody2D> ().gravityScale = 0;
		GetComponent<Rigidbody2D> ().gravityScale = 0;
	}
}
